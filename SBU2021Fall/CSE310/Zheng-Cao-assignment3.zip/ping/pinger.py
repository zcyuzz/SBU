from socket import *
import os
import sys
import struct
import time
import select
import binascii
ICMP_ECHO_REQUEST = 8

def checksum(data):
    data = bytearray(data)
    csum = 0
    countTo = (len(data) // 2) * 2

    for count in range(0, countTo, 2):
        thisVal = data[count+1] * 256 + data[count]
        csum = csum + thisVal
        csum = csum & 0xffffffff

    if countTo < len(data):
        csum = csum + data[-1]
        csum = csum & 0xffffffff

    csum = (csum >> 16) + (csum & 0xffff)
    csum = csum + (csum >> 16)
    answer = ~csum
    answer = answer & 0xffff
    answer = answer >> 8 | (answer << 8 & 0xff00)
    return answer

def receiveOnePing(mySocket, ID, timeout, destAddr):
    global rtt_min, rtt_max, rtt_sum, rtt_count
    timeLeft = timeout
    while 1:
        startedSelect = time.time()
        whatReady = select.select([mySocket], [], [], timeLeft)
        howLongInSelect = (time.time() - startedSelect)
        if whatReady[0] == []: # Timeout
            return "Request timed out."

        timeReceived = time.time()
        recPacket, _ = mySocket.recvfrom(1024)
         #Fill in start
        type_, code, _, id_, seq = struct.unpack('bbHHh', recPacket[20:28])
        if type_ != 0:
            return 'expected type=0, but got {}'.format(type_)
        if code != 0:
            return 'expected code=0, but got {}'.format(code)
        if ID != id_:
            return 'expected ID={}, but got {}'.format(ID, id_)
        send_time,  = struct.unpack('d', recPacket[28:])
        
        rtt =  1000 * (timeReceived - send_time)
        rtt_count += 1
        rtt_sum += rtt
        rtt_min = min(rtt_min, rtt)
        rtt_max = max(rtt_max, rtt)

        ip_header = struct.unpack('!BBHHHBBH4s4s' , recPacket[:20])
        ttl = ip_header[5]
        saddr = inet_ntoa(ip_header[8])
        length = len(recPacket) - 20
        #Fill in end
        return '{} bytes from {}: icmp_seq={} ttl={} time={:.3f} ms'.format(length, saddr, seq, ttl, rtt)


def sendOnePing(mySocket, destAddr, ID):
    # Header is type (8), code (8), checksum (16), id (16), sequence (16)

    myChecksum = 0
    # Make a dummy header with a 0 checksum
    # struct -- Interpret strings as packed binary data
    header = struct.pack("bbHHh", ICMP_ECHO_REQUEST, 0, myChecksum, ID, 1)
    data = struct.pack("d", time.time())
    myChecksum = checksum(header + data)

    if sys.platform == 'darwin':
        myChecksum = htons(myChecksum) & 0xffff
    # Convert 16-bit integers from host to network byte order
    else:
        myChecksum = htons(myChecksum)

    header = struct.pack("bbHHh", ICMP_ECHO_REQUEST, 0, myChecksum, ID, 1)
    packet = header + data
    mySocket.sendto(packet, (destAddr, 1)) # AF_INET address must be tuple, not str
    # Both LISTS and TUPLES consist of a number of objects

def doOnePing(destAddr, timeout):         
    icmp = getprotobyname("icmp") 
    # Socket made here
    # Using SOCK_RAW for lower level network access compared to SOCK_STREAM
     #Fill in start
    
    #Create Socket here
    mySocket = socket(AF_INET, SOCK_RAW, icmp) 
    myID = os.getpid() & 0xFFFF #Return the current process i
    sendOnePing(mySocket, destAddr, myID) 
    delay = receiveOnePing(mySocket, myID, timeout, destAddr)          
    #Fill in end
    mySocket.close()         
    return delay  

def ping(host, timeout=1):
    global rtt_min, rtt_max, rtt_sum, rtt_count
    rtt_min = float('+inf')
    rtt_max = float('-inf')
    rtt_sum = 0
    rtt_count = 0
    count = 0
    #timeout=1 means: If one second goes by without a reply from the server,
    #the client assumes that either the client's ping or the server's pong is lost
    dest = gethostbyname(host)
    print( "Pinging " + dest + " using Python:")
    # Send ping requests to a server separated by about 1 second
    try:
        while True:
            count += 1
            print (doOnePing(dest, timeout))
            time.sleep(1)
    except KeyboardInterrupt:
        if count != 0:
            print ('--- {} Ping statistics ---'.format(host))
            print ('{} Packets transmitted, {} Packets received, {:.1f}% Packet loss'.format(count, rtt_count, 100.0 - rtt_count * 100.0 / count))
            # If we made at least 1 round trip
            if rtt_count != 0:
                print ('Round-Trip Min/Avg/Max {:.3f}/{:.3f}/{:.3f} ms'.format(rtt_min, rtt_sum / rtt_count, rtt_max))

ping(sys.argv[1])